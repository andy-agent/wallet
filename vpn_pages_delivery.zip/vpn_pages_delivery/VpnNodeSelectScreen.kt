package com.example.vpn.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * 页面 1：VPN 节点选择页
 *
 * 接入说明：
 * 1. 直接替换 package 为你的项目包名。
 * 2. 把 [NodeSelectRoute] 作为页面入口接到 NavHost。
 * 3. 右侧视觉圆环是公共组件，优先把你已有组件传给 bestNodeVisual。
 * 4. 文件内提供了 DefaultBestNodeVisual() 作为占位预览，正式接入时可删。
 * 5. 全部尺寸基于 fillMaxWidth / weight / BoxWithConstraints，自适应安卓手机屏幕。
 */

private val PageBgTop = Color(0xFFF5F7FF)
private val PageBgBottom = Color(0xFFEFF8FF)
private val TitleColor = Color(0xFF111827)
private val SubtleTextColor = Color(0xFF7B8794)
private val SoftBorderColor = Color(0xFFE8EEF8)
private val AccentBlue = Color(0xFF4C74FF)
private val AccentCyan = Color(0xFF28C7E8)
private val AccentPurple = Color(0xFF8A7CFF)

@Immutable
data class NodeUiModel(
    val id: String,
    val city: String,
    val code: String,
    val description: String,
    val latencyMs: Int,
    val speedMbps: Int,
    val risk: RiskLevel,
    val recommended: Boolean = false,
)

@Immutable
data class NodeFilter(
    val key: String,
    val label: String,
)

enum class RiskLevel {
    Low,
    Medium,
    High,
}

@Composable
fun NodeSelectRoute(
    keyword: String,
    selectedFilterKey: String,
    filters: List<NodeFilter>,
    bestNode: NodeUiModel,
    nodes: List<NodeUiModel>,
    onKeywordChange: (String) -> Unit,
    onFilterSelected: (String) -> Unit,
    onAiSortClick: () -> Unit,
    onNodeClick: (NodeUiModel) -> Unit,
    bestNodeVisual: @Composable (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    Box(modifier = modifier.fillMaxSize()) {
        TechPageBackground()

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp),
            contentPadding = PaddingValues(start = 16.dp, top = 22.dp, end = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                HeaderSection(
                    eyebrow = "SMART ROUTING",
                    title = "选择最佳节点",
                    subtitle = "用延迟、速度、用途标签来选区，而不是只看国家名。",
                )
            }

            item {
                SearchBarSection(
                    keyword = keyword,
                    onKeywordChange = onKeywordChange,
                    onAiSortClick = onAiSortClick,
                )
            }

            item {
                FilterSection(
                    filters = filters,
                    selectedFilterKey = selectedFilterKey,
                    onFilterSelected = onFilterSelected,
                )
            }

            item {
                BestNodeCard(
                    node = bestNode,
                    onClick = { onNodeClick(bestNode) },
                    visual = bestNodeVisual,
                )
            }

            item {
                SectionHeader(
                    title = "全部节点",
                    trailing = "${nodes.size} 可用",
                )
            }

            items(items = nodes, key = { it.id }) { node ->
                NodeListItem(
                    node = node,
                    onClick = { onNodeClick(node) },
                )
            }
        }
    }
}

@Composable
private fun HeaderSection(
    eyebrow: String,
    title: String,
    subtitle: String,
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            text = eyebrow,
            fontSize = 12.sp,
            letterSpacing = 1.4.sp,
            color = Color(0xFF7D8FB3),
            fontWeight = FontWeight.SemiBold,
        )
        Text(
            text = title,
            fontSize = 24.sp,
            lineHeight = 30.sp,
            fontWeight = FontWeight.Bold,
            color = TitleColor,
        )
        Text(
            text = subtitle,
            fontSize = 14.sp,
            lineHeight = 20.sp,
            color = SubtleTextColor,
        )
    }
}

@Composable
private fun SearchBarSection(
    keyword: String,
    onKeywordChange: (String) -> Unit,
    onAiSortClick: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        OutlinedTextField(
            value = keyword,
            onValueChange = onKeywordChange,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(20.dp),
            singleLine = true,
            placeholder = {
                Text(text = "搜索国家 / 城市 / 用途", color = SubtleTextColor)
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Outlined.Search,
                    contentDescription = null,
                    tint = SubtleTextColor,
                )
            },
        )

        Spacer(modifier = Modifier.width(10.dp))

        TextButton(
            onClick = onAiSortClick,
            modifier = Modifier
                .height(52.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Color.White.copy(alpha = 0.72f)),
        ) {
            Text(
                text = "AI排序",
                color = AccentBlue,
                fontWeight = FontWeight.SemiBold,
            )
        }
    }
}

@Composable
private fun FilterSection(
    filters: List<NodeFilter>,
    selectedFilterKey: String,
    onFilterSelected: (String) -> Unit,
) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(filters, key = { it.key }) { filter ->
            FilterChip(
                selected = filter.key == selectedFilterKey,
                onClick = { onFilterSelected(filter.key) },
                label = { Text(text = filter.label) },
            )
        }
    }
}

@Composable
private fun BestNodeCard(
    node: NodeUiModel,
    onClick: () -> Unit,
    visual: @Composable (() -> Unit)? = null,
) {
    BoxWithConstraints {
        val compactScreen = maxWidth < 360.dp
        val ringSize = if (compactScreen) 72.dp else 92.dp

        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onClick),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text(
                        text = "当前最优",
                        fontSize = 12.sp,
                        color = Color(0xFF94A3B8),
                        fontWeight = FontWeight.Medium,
                    )
                    Text(
                        text = "${node.city} ・ ${node.code}",
                        fontSize = if (compactScreen) 24.sp else 28.sp,
                        lineHeight = if (compactScreen) 30.sp else 34.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontWeight = FontWeight.Bold,
                        color = TitleColor,
                    )
                    Text(
                        text = node.description,
                        fontSize = 13.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        color = SubtleTextColor,
                    )

                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        MetricBox(label = "LATENCY", value = "${node.latencyMs} ms")
                        MetricBox(label = "SPEED", value = "${node.speedMbps} Mbps")
                        MetricBox(label = "RISK", value = node.risk.name)
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Box(
                    modifier = Modifier.size(ringSize),
                    contentAlignment = Alignment.Center,
                ) {
                    if (visual != null) {
                        visual()
                    } else {
                        DefaultBestNodeVisual()
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricBox(
    label: String,
    value: String,
) {
    Column(
        modifier = Modifier
            .defaultMinSize(minWidth = 84.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.75f))
            .padding(horizontal = 12.dp, vertical = 10.dp),
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            color = Color(0xFF94A3B8),
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            fontSize = 15.sp,
            color = TitleColor,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

@Composable
private fun SectionHeader(
    title: String,
    trailing: String,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Bottom,
    ) {
        Text(
            text = title,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = TitleColor,
        )
        Text(
            text = trailing,
            fontSize = 13.sp,
            color = Color(0xFF94A3B8),
        )
    }
}

@Composable
private fun NodeListItem(
    node: NodeUiModel,
    onClick: () -> Unit,
) {
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        cornerRadius = 20.dp,
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 15.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(
                    text = "${node.city} ・ ${node.code}",
                    fontSize = 18.sp,
                    lineHeight = 23.sp,
                    fontWeight = FontWeight.Bold,
                    color = TitleColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = node.description,
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    color = SubtleTextColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Text(
                    text = "${node.latencyMs} ms",
                    fontSize = 13.sp,
                    color = Color(0xFF6B7280),
                    fontWeight = FontWeight.Medium,
                )
                SpeedBar(progress = speedToProgress(node.speedMbps))
                Text(
                    text = "${node.speedMbps} Mbps",
                    fontSize = 13.sp,
                    color = Color(0xFF94A3B8),
                )
            }
        }
    }
}

@Composable
private fun SpeedBar(progress: Float) {
    Canvas(
        modifier = Modifier
            .width(96.dp)
            .height(8.dp),
    ) {
        drawRoundRect(
            color = Color(0xFFE5EDF8),
            size = size,
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(100f, 100f),
        )
        drawRoundRect(
            brush = Brush.horizontalGradient(listOf(AccentBlue, AccentCyan)),
            size = Size(width = size.width * progress.coerceIn(0f, 1f), height = size.height),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(100f, 100f),
        )
    }
}

private fun speedToProgress(speedMbps: Int): Float = (speedMbps / 100f).coerceIn(0f, 1f)

@Composable
private fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: androidx.compose.ui.unit.Dp = 24.dp,
    content: @Composable () -> Unit,
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(cornerRadius),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.82f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
    ) {
        Box(
            modifier = Modifier
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.65f),
                            Color(0xFFF2FAFF).copy(alpha = 0.6f),
                        ),
                    ),
                )
                .padding(0.dp),
        ) {
            content()
        }
    }
}

@Composable
private fun TechPageBackground() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(colors = listOf(PageBgTop, PageBgBottom))),
    ) {
        BackgroundGlow(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 8.dp, end = 0.dp)
                .size(220.dp),
            color = AccentPurple.copy(alpha = 0.18f),
        )
        BackgroundGlow(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 120.dp)
                .size(260.dp),
            color = AccentCyan.copy(alpha = 0.14f),
        )
        TechDots()
    }
}

@Composable
private fun BackgroundGlow(
    modifier: Modifier,
    color: Color,
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(999.dp))
            .background(color)
            .blur(36.dp),
    )
}

@Composable
private fun TechDots() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val points = listOf(
            Offset(size.width * 0.08f, size.height * 0.18f),
            Offset(size.width * 0.22f, size.height * 0.82f),
            Offset(size.width * 0.48f, size.height * 0.40f),
            Offset(size.width * 0.66f, size.height * 0.62f),
            Offset(size.width * 0.84f, size.height * 0.14f),
            Offset(size.width * 0.90f, size.height * 0.88f),
        )
        points.forEachIndexed { index, point ->
            drawCircle(
                color = if (index % 2 == 0) AccentCyan.copy(alpha = 0.24f) else AccentPurple.copy(alpha = 0.22f),
                radius = if (index % 2 == 0) 4f else 3f,
                center = point,
            )
        }
    }
}

@Composable
private fun DefaultBestNodeVisual() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val stroke = size.minDimension * 0.09f
        val outerRadius = size.minDimension / 2.2f
        val center = Offset(size.width / 2f, size.height / 2f)

        drawCircle(color = AccentCyan.copy(alpha = 0.10f), radius = outerRadius * 1.06f, center = center)
        drawCircle(color = Color.White.copy(alpha = 0.95f), radius = outerRadius * 0.54f, center = center)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(AccentBlue.copy(alpha = 0.10f), Color.Transparent),
                center = center,
                radius = outerRadius * 1.25f,
            ),
            radius = outerRadius * 1.25f,
            center = center,
        )
        drawArc(
            brush = Brush.sweepGradient(listOf(AccentBlue, AccentCyan, AccentPurple, AccentBlue)),
            startAngle = -80f,
            sweepAngle = 300f,
            useCenter = false,
            topLeft = Offset(center.x - outerRadius, center.y - outerRadius),
            size = Size(outerRadius * 2, outerRadius * 2),
            style = Stroke(width = stroke, cap = StrokeCap.Round),
        )
    }
}

@Preview(showBackground = true, backgroundColor = 0xFFF4F7FF)
@Composable
private fun NodeSelectRoutePreview() {
    MaterialTheme {
        Surface {
            NodeSelectRoute(
                keyword = "",
                selectedFilterKey = "recommend",
                filters = sampleFilters,
                bestNode = sampleNodes.first(),
                nodes = sampleNodes,
                onKeywordChange = {},
                onFilterSelected = {},
                onAiSortClick = {},
                onNodeClick = {},
            )
        }
    }
}

private val sampleFilters = listOf(
    NodeFilter("recommend", "推荐"),
    NodeFilter("asia", "亚洲"),
    NodeFilter("europe", "欧洲"),
    NodeFilter("america", "美洲"),
    NodeFilter("lowdelay", "低延迟"),
)

private val sampleNodes = listOf(
    NodeUiModel(
        id = "jp-01",
        city = "东京",
        code = "JP-01",
        description = "专线出口・视频流媒体・钱包交易确认优先",
        latencyMs = 41,
        speedMbps = 89,
        risk = RiskLevel.Low,
        recommended = true,
    ),
    NodeUiModel(
        id = "sg-09",
        city = "新加坡",
        code = "SG-09",
        description = "稳定・入口/出口已双向检测",
        latencyMs = 52,
        speedMbps = 82,
        risk = RiskLevel.Low,
    ),
    NodeUiModel(
        id = "de-03",
        city = "法兰克福",
        code = "DE-03",
        description = "低拥堵・入口/出口已双向检测",
        latencyMs = 138,
        speedMbps = 71,
        risk = RiskLevel.Medium,
    ),
    NodeUiModel(
        id = "us-12",
        city = "洛杉矶",
        code = "US-12",
        description = "流媒体・入口/出口已双向检测",
        latencyMs = 168,
        speedMbps = 65,
        risk = RiskLevel.Medium,
    ),
    NodeUiModel(
        id = "hk-06",
        city = "香港",
        code = "HK-06",
        description = "智能分流・入口/出口已双向检测",
        latencyMs = 46,
        speedMbps = 86,
        risk = RiskLevel.Low,
    ),
)
