package com.example.vpn.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * 页面 2：订阅购买页
 *
 * 接入说明：
 * 1. 直接替换 package 为你的项目包名。
 * 2. 入口是 [SubscriptionPlanRoute]。
 * 3. 页面底部 CTA 已经预留 onPayClick，接钱包支付逻辑即可。
 * 4. 支持当前套餐状态 + 套餐列表 + 推荐高亮 + 标签 Chips。
 * 5. 布局以 LazyColumn + 底部安全区按钮为主，适配安卓手机长屏和小屏。
 */

private val SubscriptionBgTop = Color(0xFFF5F6FF)
private val SubscriptionBgBottom = Color(0xFFEFF8FF)
private val SubscriptionTitle = Color(0xFF101828)
private val SubscriptionSubtle = Color(0xFF98A2B3)
private val TagTextColor = Color(0xFF5A78FF)
private val GradientStart = Color(0xFF4C74FF)
private val GradientEnd = Color(0xFF21C7E8)

@Immutable
data class SubscriptionStatusUi(
    val currentPlanName: String,
    val accessDescription: String,
    val payMethodName: String,
    val payMethodDescription: String,
    val remainingDaysText: String,
    val payEnabledText: String = "支持钱包直付",
)

@Immutable
data class SubscriptionPlanUi(
    val id: String,
    val title: String,
    val priceText: String,
    val description: String,
    val tags: List<String> = emptyList(),
    val recommendedBadge: String? = null,
)

@Composable
fun SubscriptionPlanRoute(
    status: SubscriptionStatusUi,
    plans: List<SubscriptionPlanUi>,
    selectedPlanId: String,
    onPlanClick: (SubscriptionPlanUi) -> Unit,
    onPayClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(modifier = modifier.fillMaxSize()) {
        SubscriptionBackground()

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp),
            contentPadding = PaddingValues(start = 16.dp, top = 22.dp, end = 16.dp, bottom = 108.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                SubscriptionHeader(status.payEnabledText)
            }

            item {
                CurrentStatusCard(status = status)
            }

            items(items = plans, key = { it.id }) { plan ->
                SubscriptionPlanCard(
                    plan = plan,
                    selected = plan.id == selectedPlanId,
                    onClick = { onPlanClick(plan) },
                )
            }
        }

        BottomPayBar(
            onPayClick = onPayClick,
            modifier = Modifier.align(Alignment.BottomCenter),
        )
    }
}

@Composable
private fun SubscriptionHeader(payEnabledText: String) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "SUBSCRIPTION",
                    fontSize = 12.sp,
                    letterSpacing = 1.4.sp,
                    color = Color(0xFF7D8FB3),
                    fontWeight = FontWeight.SemiBold,
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "购买你的套餐",
                    fontSize = 24.sp,
                    lineHeight = 30.sp,
                    color = SubscriptionTitle,
                    fontWeight = FontWeight.Bold,
                )
            }

            StatusPill(
                text = payEnabledText,
                icon = Icons.Outlined.CheckCircle,
            )
        }

        Text(
            text = "VPN 是核心服务，钱包是支付与资产层。这里把它们真正融合。",
            fontSize = 14.sp,
            lineHeight = 20.sp,
            color = SubscriptionSubtle,
        )
    }
}

@Composable
private fun StatusPill(
    text: String,
    icon: ImageVector,
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(Color(0xFFEFFBF5))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        androidx.compose.material3.Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color(0xFF22A06B),
            modifier = Modifier.size(14.dp),
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = text,
            fontSize = 12.sp,
            color = Color(0xFF22A06B),
            fontWeight = FontWeight.SemiBold,
        )
    }
}

@Composable
private fun CurrentStatusCard(status: SubscriptionStatusUi) {
    FrostCard {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "当前状态",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = SubscriptionTitle,
                )
                Text(
                    text = status.remainingDaysText,
                    fontSize = 13.sp,
                    color = SubscriptionSubtle,
                    fontWeight = FontWeight.Medium,
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                StatusInfoBlock(
                    title = "当前计划",
                    value = status.currentPlanName,
                    subtitle = status.accessDescription,
                    modifier = Modifier.weight(1f),
                )
                StatusInfoBlock(
                    title = "支付资产",
                    value = status.payMethodName,
                    subtitle = status.payMethodDescription,
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

@Composable
private fun StatusInfoBlock(
    title: String,
    value: String,
    subtitle: String,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White.copy(alpha = 0.72f))
            .padding(horizontal = 14.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text(
            text = title,
            fontSize = 12.sp,
            color = SubscriptionSubtle,
            fontWeight = FontWeight.Medium,
        )
        Text(
            text = value,
            fontSize = 18.sp,
            color = SubscriptionTitle,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            text = subtitle,
            fontSize = 12.sp,
            lineHeight = 16.sp,
            color = TagTextColor,
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun SubscriptionPlanCard(
    plan: SubscriptionPlanUi,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val cardBrush = if (selected) {
        Brush.linearGradient(
            listOf(
                Color(0xFFF2F8FF),
                Color(0xFFEFFBFF),
            ),
        )
    } else {
        Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = 0.84f),
                Color.White.copy(alpha = 0.80f),
            ),
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.78f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
    ) {
        Column(
            modifier = Modifier
                .background(cardBrush)
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top,
            ) {
                Text(
                    text = plan.title,
                    fontSize = 18.sp,
                    color = SubscriptionTitle,
                    fontWeight = FontWeight.Bold,
                )
                if (plan.recommendedBadge != null) {
                    Text(
                        text = plan.recommendedBadge,
                        fontSize = 12.sp,
                        color = TagTextColor,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }

            Text(
                text = plan.priceText,
                fontSize = 26.sp,
                lineHeight = 30.sp,
                color = SubscriptionTitle,
                fontWeight = FontWeight.ExtraBold,
            )

            Text(
                text = plan.description,
                fontSize = 13.sp,
                lineHeight = 18.sp,
                color = SubscriptionSubtle,
            )

            if (plan.tags.isNotEmpty()) {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    plan.tags.forEach { tag ->
                        SmallTag(text = tag)
                    }
                }
            }
        }
    }
}

@Composable
private fun SmallTag(text: String) {
    Text(
        text = text,
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(Color(0xFFF2F6FF))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        fontSize = 12.sp,
        color = TagTextColor,
        fontWeight = FontWeight.SemiBold,
    )
}

@Composable
private fun BottomPayBar(
    onPayClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.White.copy(alpha = 0.22f))
            .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
        Button(
            onClick = onPayClick,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            contentPadding = PaddingValues(),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Brush.horizontalGradient(listOf(GradientStart, GradientEnd))),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = "使用钱包支付并开通",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                )
            }
        }
    }
}

@Composable
private fun FrostCard(content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.82f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
    ) {
        Box(
            modifier = Modifier.background(
                brush = Brush.linearGradient(
                    listOf(
                        Color.White.copy(alpha = 0.60f),
                        Color(0xFFF3FBFF).copy(alpha = 0.56f),
                    ),
                ),
            ),
        ) {
            content()
        }
    }
}

@Composable
private fun SubscriptionBackground() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(colors = listOf(SubscriptionBgTop, SubscriptionBgBottom))),
    ) {
        SoftGlow(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .size(220.dp),
            color = Color(0xFF9B8CFF).copy(alpha = 0.18f),
        )
        SoftGlow(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 90.dp)
                .size(260.dp),
            color = Color(0xFF61DFFF).copy(alpha = 0.16f),
        )
        SubscriptionDots()
    }
}

@Composable
private fun SoftGlow(
    modifier: Modifier,
    color: Color,
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(999.dp))
            .background(color)
            .blur(42.dp),
    )
}

@Composable
private fun SubscriptionDots() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val points = listOf(
            Offset(size.width * 0.06f, size.height * 0.12f),
            Offset(size.width * 0.18f, size.height * 0.54f),
            Offset(size.width * 0.30f, size.height * 0.86f),
            Offset(size.width * 0.52f, size.height * 0.42f),
            Offset(size.width * 0.78f, size.height * 0.62f),
            Offset(size.width * 0.90f, size.height * 0.20f),
        )
        points.forEachIndexed { index, point ->
            drawCircle(
                color = if (index % 2 == 0) Color(0xFF5ED8F8).copy(alpha = 0.22f) else Color(0xFF9A90FF).copy(alpha = 0.20f),
                radius = if (index % 2 == 0) 4f else 3f,
                center = point,
            )
        }
    }
}

@Preview(showBackground = true, backgroundColor = 0xFFF5F7FF)
@Composable
private fun SubscriptionPlanRoutePreview() {
    MaterialTheme {
        Surface {
            SubscriptionPlanRoute(
                status = sampleSubscriptionStatus,
                plans = samplePlans,
                selectedPlanId = "yearly-pro",
                onPlanClick = {},
                onPayClick = {},
            )
        }
    }
}

private val sampleSubscriptionStatus = SubscriptionStatusUi(
    currentPlanName = "Pro 月付",
    accessDescription = "东京 ・ 新加坡专线",
    payMethodName = "USDT",
    payMethodDescription = "TRON / Solana 可选",
    remainingDaysText = "还剩 2 天",
)

private val samplePlans = listOf(
    SubscriptionPlanUi(
        id = "monthly",
        title = "月度",
        priceText = "$8.90",
        description = "适合首次体验，按月续费",
        tags = listOf("SOL", "USDT-SOL", "USDT-TRON"),
    ),
    SubscriptionPlanUi(
        id = "yearly-pro",
        title = "年度 Pro",
        priceText = "$58.00",
        description = "节省 46%，开放高速专线与隐私路由",
        tags = listOf("高速专线", "智能分区", "钱包直付"),
        recommendedBadge = "最受欢迎",
    ),
    SubscriptionPlanUi(
        id = "team",
        title = "团队版",
        priceText = "$149.00",
        description = "最多 5 台设备，适合小团队与多端钱包使用",
    ),
)
