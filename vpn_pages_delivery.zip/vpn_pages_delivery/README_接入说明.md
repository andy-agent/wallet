# 交付说明

本压缩包包含 2 个 Jetpack Compose 页面文件：

1. `VpnNodeSelectScreen.kt`
2. `SubscriptionPlanScreen.kt`

## 页面说明

### 1) VpnNodeSelectScreen.kt
- 用途：VPN 节点选择页
- 入口函数：`NodeSelectRoute(...)`
- 关键能力：
  - 搜索框
  - 筛选 Chips
  - 当前最优节点卡片
  - 全部节点列表
  - 自适应安卓手机屏幕
- 特别说明：
  - 右侧圆环视觉组件是公共组件，所以我做成了参数 `bestNodeVisual`
  - 你们原项目如果已经有公共圆环组件，直接传进去即可
  - 如果暂时没有，文件内 `DefaultBestNodeVisual()` 可以先顶上

### 2) SubscriptionPlanScreen.kt
- 用途：订阅购买页
- 入口函数：`SubscriptionPlanRoute(...)`
- 关键能力：
  - 顶部状态提示
  - 当前套餐状态卡片
  - 套餐列表
  - 推荐套餐高亮
  - 底部支付按钮
  - 自适应安卓手机屏幕

## 接入建议

1. 把两个文件里的 package 改成你项目自己的包名
2. 把两个 Route 入口接到 NavHost 或页面容器
3. 用你自己的 ViewModel / StateFlow 替换预览数据
4. `onNodeClick`、`onPlanClick`、`onPayClick` 接你们现有业务逻辑
5. 如果你们项目有统一主题色，可以把文件顶部颜色常量迁到 Theme

## 依赖要求

基于 Jetpack Compose Material 3：
- compose-ui
- foundation
- material3
- ui-tooling-preview
- material-icons-extended（因为用了 `Icons.Outlined.Search` 和 `Icons.Outlined.CheckCircle`）

## 我已做的回归检查

这次交付前，我做了 1 次静态回归检查，检查点包括：
- 两个 `.kt` 文件已成功写出
- 文件内页面入口、预览函数、示例数据都在各自文件内闭环
- 两个页面的主要引用没有互相缺失
- 布局使用 `LazyColumn + fillMaxWidth + weight + widthIn`，适合安卓手机屏幕自适应

## 注意

由于当前环境不是完整 Android Studio / Gradle 工程，无法像本地项目那样执行真正的 Compose 编译和设备运行。
所以我这边做的是“静态回归检查 + 结构闭环检查”。
你接给另一个 AI 或开发同事后，建议再在项目里跑一次 Preview / assembleDebug。
